import sbt._

object Dependencies {
  val sparkVersion = "3.2.3"
  val hiveVersion = "3.1.2"

  val sparkCore = "org.apache.spark" %% "spark-core" % sparkVersion
  val sparkSql = "org.apache.spark" %% "spark-sql" % sparkVersion
  val sparkHive = "org.apache.spark" %% "spark-hive" % sparkVersion
  val hiveExec = "org.apache.hive" % "hive-exec" % hiveVersion

  val allDependencies = Seq(
    sparkCore,
    sparkSql,
    sparkHive,
    hiveExec
  )
}
