package com.example

import org.apache.spark.sql.{DataFrame, SparkSession}

object DataLoader {
  def loadData(spark: SparkSession, directory: String): DataFrame = {
    val combinedDf = spark.read.parquet(directory)
    combinedDf.na.replace("*", Map("" -> null))
  }
}
