package com.example

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.log4j.{Level, Logger}

object Main {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("Customer Transaction Analysis")
      .getOrCreate()

    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)

    val customerDirectory = "/home/labuser/Desktop/Persistant_Folder/data/profiles_data/"
    val transactionDirectory = "/home/labuser/Desktop/Persistant_Folder/data/txn_skewed/"

    val customerDf = DataLoader.loadData(spark, customerDirectory)
    val transactionDf = DataLoader.loadData(spark, transactionDirectory)

    println("Performing data quality checks on customer DataFrame:")
    DataQualityChecker.performDQChecks(customerDf)(spark)

    println("Performing data quality checks on transaction DataFrame:")
    DataQualityChecker.performDQChecks(transactionDf)(spark)

    val joinedDf: DataFrame = transactionDf.join(customerDf, Seq("source_system_id"), "inner")

    DataAnalyzer.analyzeData(spark, joinedDf)
    spark.stop()
  }
}
