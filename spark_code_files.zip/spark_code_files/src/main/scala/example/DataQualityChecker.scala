package com.example

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Encoders

object DataQualityChecker {
  def performDQChecks(df: DataFrame)(implicit spark: SparkSession): Unit = {
    val nullCounts = df.columns.map { c =>
      count(when(col(c).isNull, c)).alias(c)
    }

    val nullCountDf = df.agg(nullCounts.head, nullCounts.tail: _*)
    println("Null value counts per column:")
    nullCountDf.show()

    val rowCount = df.count()
    println(s"Number of rows in the DataFrame: $rowCount")

    val distinctCounts = df.columns.map { c =>
      countDistinct(c).alias(c)
    }

    val distinctCountDf = df.agg(distinctCounts.head, distinctCounts.tail: _*)
    println("Distinct count for each column:")
    distinctCountDf.show()

    val duplicateCount = df.count() - df.distinct().count()
    println(s"Number of duplicate rows: $duplicateCount")

    checkSkewness(df)
  }

  def checkSkewness(df: DataFrame)(implicit spark: SparkSession): Unit = {
    val numericCols = df.schema.fields.filter(_.dataType.typeName == "double").map(_.name)

    val skewnesses: Array[(String, Double)] = numericCols.map { colName =>
      val skewnessValue = df.agg(skewness(colName)).as[Double](Encoders.scalaDouble).collect().headOption.getOrElse(0.0)
      (colName, skewnessValue)
    }

    val skewnessValues = skewnesses.map(_._2)
    val meanSkewness = skewnessValues.sum / skewnessValues.length
    val stdDevSkewness = math.sqrt(skewnessValues.map(s => math.pow(s - meanSkewness, 2)).sum / skewnessValues.length)

    val skewnessThreshold = meanSkewness + 2 * stdDevSkewness

    println(s"Dynamic Skewness Threshold: $skewnessThreshold")
    println("Checking skewness for numeric columns:")

    skewnesses.foreach { case (colName, skewnessValue) =>
      println(s"Skewness of $colName: $skewnessValue")
      if (math.abs(skewnessValue) > skewnessThreshold) {
        println(s"Warning: $colName is skewed (skewness: $skewnessValue)")
      }
    }
  }
}
