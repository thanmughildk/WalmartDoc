package com.example

import org.apache.spark.sql.{DataFrame, SparkSession}

object DataAnalyzer {
  def analyzeData(spark: SparkSession, df: DataFrame): Unit = {
    DataQualityChecker.performDQChecks(df)(spark)

    MetricsCalculator.calculateMetrics(df)
    // MetricsCalculator.forecastSales(df)
    MetricsCalculator.generateInsights(df)
  }
}
