package com.example

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object MetricsCalculator {

  def calculateMetrics(df: DataFrame): Unit = {
    val basketSize = df.groupBy("customerId").agg(count("prod_id").alias("basket_size"))
    val avgBasketSize = basketSize.agg(avg("basket_size"))

    val dollarPerCustomer = df.groupBy("customerId").agg(sum("total_price").alias("total_spent"))
    val avgDollarPerCustomer = dollarPerCustomer.agg(avg("total_spent"))

    println(s"Average Basket Size: $avgBasketSize")
    println(s"Average Dollar per Customer: $avgDollarPerCustomer")
  }

  def forecastSales(df: DataFrame): Unit = {
    // Forecast sales for the next 3 months
  }

  def calculateHeavySpenders(df: DataFrame): Unit = {
    val heavySpenders = df.groupBy("customerId", "name")
      .agg(sum("total_price").alias("total_spent"))
      .orderBy(desc("total_spent"))

    val windowSpec = org.apache.spark.sql.expressions.Window.orderBy(desc("total_spent"))
    val rankedSpenders = heavySpenders.withColumn("rank", dense_rank().over(windowSpec))

    rankedSpenders.filter(col("rank") <= 20).show()
  }

  def calculateFrequentItems(df: DataFrame): Unit = {
    val frequentItems = df.groupBy("prod_id", "product_name")
      .agg(count("*").alias("purchase_count"))
      .orderBy(desc("purchase_count"))

    frequentItems.limit(20).show()
  }

  def generateInsights(df: DataFrame): Unit = {
    calculateHeavySpenders(df)
    calculateFrequentItems(df)
  }
}
